package main

import "github.com/Nodeist/Nodecord/cmd"

func main() {
	cmd.Execute()
}
